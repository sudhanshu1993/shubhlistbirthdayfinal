    <div class="divider">
        <div class="container">
            <div class="dividers">

            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="container">

            <div class="footer__options">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="footer__widget footer__widget--address">

                            <div id="media_image-9" class="widget widget_media_image">
                                <a href="#">
                                    <img src="{{asset('Template/img/logo.png')}}" class="">
                                </a>
                            </div>


                            <ul class="adf">
                                <li class="phone-nu">(123) 8111 9210 </li>
                                <li>102580 Santa Monica BLVD Los Angeles</li>

                                <li><a href="#" class="__cf_email__">info@shubhlist.com</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-3">
                        <div class="footer__widget">
                            <h4>Corporate</h4>
                            <ul>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Green</a></li>
                                <li><a href="#">Afiliates</a></li>
                                <li><a href="#">Non-Profits & Government</a></li>
                                <li><a href="#">Terms Of Service</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3">
                        <div class="footer__widget">
                            <h4>Support</h4>
                            <ul>
                                <li><a href="#">My Account</a></li>
                                <li><a href="#">Design Guide</a></li>
                                <li><a href="#">FAQ</a></li>
                                <li><a href="#">Design Services</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-3">
                        <div class="footer__widget">
                            <h4>Social Media</h4>
                            <ul>
                                <li><a href="#">Facebook</a></li>
                                <li><a href="#">Instagram</a></li>
                                <li><a href="#">Whatsapp</a></li>
                                <li><a href="#">Telegram</a></li>                                
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
            <div class="footer__copyright">
                <div class="row">
                    <div class="col-lg-12 text-center">

                        <p>Copyright &copy;
                            <script>document.write(new Date().getFullYear());</script>Craftmedia All rights reserved |
                            Designed by <a href="https://cssfounder.com/" target="_blank" rel="nofollow noopener">Css
                                Founder.com</a>
                        </p>

                    </div>
                </div>
            </div>
        </div>
    </footer>

    <div class="search-model">
        <div class="h-100 d-flex align-items-center justify-content-center">
            <div class="search-close-switch">+</div>
            <form class="search-model-form">
                <input type="text" id="search-input" placeholder="Search here.....">
            </form>
        </div>
    </div>
